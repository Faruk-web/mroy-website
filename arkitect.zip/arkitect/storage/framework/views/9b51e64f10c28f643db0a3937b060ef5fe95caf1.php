
<?php $__env->startSection('title'); ?>
    Contact us
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
 
<div class="breadcumb-wrapper " data-bg-src="<?php echo e(asset('front')); ?>/assets/img/bg/breadcrumb-bg.jpg" data-overlay="title" data-opacity="8">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Support Teams</h1>
                <ul class="breadcumb-menu">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li>Support Teams</li>
                </ul>
            </div>
        </div>
    </div>
    <!--==============================
Team Area  
==============================-->
    <section class="space" id="team-sec" data-bg-src="<?php echo e(asset('front')); ?>/assets/img/bg/team-2-shape-bg.png">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xxl-8 col-xl-9 ">
                    <div class="title-area text-center">
                        <span class="sub-title justify-content-center">Support Teams</span>
                        <h2 class="sec-title">Meet Our Support Team</h2>
                    </div>
                </div>
                <div></div>
            </div>
            <div class="row gy-4">
                <!-- Single Item -->
                <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-4 col-lg-4 col-sm-6">
                    <div class="team-card style-2">
                        <div class="team-img">
                            <img src="<?php echo e(asset($item->image)); ?>" alt="Team">
                        </div>
                        <div class="team-content">
                            <h3 class="box-title"><a href="<?php echo e(route('team.detail',$item->id)); ?>"><?php echo e($item->name); ?></a></h3>
                            <span class="team-desig"><?php echo e($item->title); ?></span>

                            <div class="team-social">
                              <a href="<?php echo e(route('team.detail',$item->id)); ?>" class="link-btn"> Read More <i class="fa-regular fa-arrow-right-long"></i> </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OneDrive - Amin Mohammad Foundation Ltd\Documents\mroy-website\arkitect\resources\views/front/terms/terms.blade.php ENDPATH**/ ?>